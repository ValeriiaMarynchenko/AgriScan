// TODO API-запити для Auth.
//  Містить усі чисті функції для виклику бекенду,
//  пов'язані з авторизацією: login(email, password),
//  registerStep1(email), verifyOTP(uid, token),
//  setNewPassword(password), loginWithGoogle().