// TODO API-запити для Аналізу.
//  Містить функції для завантаження фото та
//  перевірки статусу завдання: uploadImage(file, fieldId),
//  getAnalysisStatus(jobId).