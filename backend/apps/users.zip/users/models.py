from django.db import models

# Create your models here.
# apps/users/models.py
from django.contrib.auth.models import AbstractUser
from django.db import models


# Константа для ролей
class UserRole(models.TextChoices):
    # Користувач, який керує своїми полями
    FARMER = 'FARMER', 'Фермер'
    # Користувач-адміністратор платформи
    ADMIN = 'ADMIN', 'Адміністратор'
    # Користувач, що має лише доступ до звітів
    VIEWER = 'VIEWER', 'Спостерігач'


class CustomUser(AbstractUser):

    id = models.BigAutoField(primary_key=True)
    # Використовуємо email як унікальний ідентифікатор для входу
    # (Це вимагає додаткового налаштування Manager, див. пункт 3)
    email = models.EmailField(unique=True, verbose_name='Електронна пошта')

    # Додаємо нове поле для ролі користувача
    role = models.CharField(
        max_length=10,
        choices=UserRole.choices,
        default=UserRole.FARMER,
        verbose_name='Роль користувача'
    )

    # Додаткові поля, які можуть знадобитися
    organization_name = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name='Назва організації'
    )

    # Видаляємо поле username, щоб вхід був лише через email
    # username = None # Розкоментуйте, якщо хочете видалити username повністю

    # Вказуємо, що поле 'email' використовується для входу
    USERNAME_FIELD = 'email'

    # Поля, які будуть запитані при створенні суперкористувача
    REQUIRED_FIELDS = ['first_name', 'last_name']  # Якщо username=None, додайте first_name, last_name сюди

    class Meta:
        verbose_name = 'Користувач'
        verbose_name_plural = 'Користувачі'

    def __str__(self):
        return self.email