// input type="file"    //space for file uploading

// "Аналізувати"        //button for analise running
// /api/analysis/       //TODO POST by multipart/form-data (what is it????????????)

//TODO Форма Взаємодії з ШІ. UI для вибору та
// завантаження файлу. Після успішного завантаження
// запускає поллінг (перевірку статусу) і відображає
// отриманий result_url (вихідне зображення).